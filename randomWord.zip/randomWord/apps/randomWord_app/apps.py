from django.apps import AppConfig


class RandomwordAppConfig(AppConfig):
    name = 'randomWord_app'
