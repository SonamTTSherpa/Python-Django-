from django.shortcuts import render, redirect
import bcrypt
from .models import *
from django.contrib import messages
from time import strftime, strptime


def index(request):
    
    return render(request, "users/index.html")

def process_reg(request):
    errors = User.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        hash1 = bcrypt.hashpw(request.POST["pw"].encode(), bcrypt.gensalt())
        new_user = User.objects.create(first_name=request.POST["fname"], last_name=request.POST["lname"],email=request.POST["email"],pw_hash=hash1)
        request.session["userid"] = new_user.id
        messages.success(request, "Successfully registered!")
        return redirect("/success")

def email(request):
    found = False
    result = User.objects.filter(email=request.POST["email"])
    if len(result) > 0:
        found = True
    context = {
        "found_html": found
    }
    return render(request, "users/partials/email.html", context)

def success(request):
    if not "userid" in request.session:
        messages.error(request, "You are not logged in.")
        return redirect("/")
    else:
        user = User.objects.get(id=request.session["userid"])
        context = {
            "user_html": user,
            "all_qutoes": Qutoes.objects.all(),
        }
        return render(request, "users/success.html", context)

def new_qutoe(request):
    poster = request.session["userid"]
    poster = User.objects.get(id=poster)
    if len(request.POST["author"]) > 3 and len(request.POST["qutoe"]) > 10:
        Qutoes.objects.create(author=request.POST["author"], qutoe=request.POST["qutoe"], user=poster)
        messages.add_message(request, messages.INFO, "Info added!")
    else:
        messages.add_message(request, messages.INFO, "Info could not be added. Author: More than 3 characters and Quote: More than 10 characters.")
    
    return redirect("/success")


def login(request):
    try:
        User.objects.get(email=request.POST["email"])
    except:
        messages.error(request,"User does not exist.")
        return redirect("/")
    email_match = User.objects.get(email=request.POST["email"]) 
    if bcrypt.checkpw(request.POST["pw"].encode(), email_match.pw_hash.encode()):
        request.session["userid"] = email_match.id
        messages.success(request, "Successfully logged in!")
        return redirect("/success")
    else:
        messages.error(request, "Incorrect password.")
        return redirect("/")

def logout(request):
    request.session.clear()
    return redirect("/")

def edit(request, quoteID):#RENDER ROUTE, MAKES THE PAGE
    context = {
        'thisQuote': Qutoes.objects.get(id=quoteID),
    }
    return render(request, 'edit.html', context)

def editProcess(request, quoteID):#PROCESS ROUTE, MODIFIES TABLE
    errors = User.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        thisQutoe = Qutoes.objects.get(id=quoteID)
        newAuthor = request.POST['author']
        newQutoe = request.POST['quote']
    
        thisQutoe.author = newAuthor
        thisQutoe.qutoe = newQutoe
        thisQutoe.save()
        return redirect('/success')

# def create(request):#RENDER ROUTE, MAKES THE PAGE
   
#     return render(request, 'create.html')

# def createProcess(request):#PROCESS ROUTE, MODIFIES TABLE
#     errors = Trip.objects.basic_validator(request.POST)
#     if len(errors) > 0:
#         for key, value in errors.items():
#             messages.error(request, value)
#         return redirect("/success")
#     else:
#         thisTrip = Trip.objects.create(
#         destination=request.POST['dest'],
#         start_date=request.POST['start'],
#         end_date=request.POST['end'],
#         plan=request.POST['plan'],
#         user=User.objects.get(id=request.session["userid"]))
#         tripID = thisTrip.id
#         return redirect ("/success")

# def view(request, tripID):
#     thisTrip= Trip.objects.get(id=tripID)
    
#     context = {
#         "release_date_html": format_release,
#         "show_html": new_show,
#     }
    
#     return render(request, "shows_app/viewshow.html", context)


       