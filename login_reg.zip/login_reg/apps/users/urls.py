from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^registration/process$', views.process_reg),
    url(r'^success$', views.success),
    url(r'^new_qutoe$', views.new_qutoe),
    url(r'^trip/(?P<tripID>\d+)/edit$', views.edit),
    url(r'^trip/(?P<tripID>\d+)/edit/process$', views.editProcess),
    # url(r'^trip/(?P<tripID>\d+)/view$', views.view),
    # url(r'^trip/(?P<tripID>\d+)/view/process$', views.viewProcess),
    # url(r'^trip/(?P<tripID>\d+)/delete$', views.delete),
    # url(r'^trip/(?P<tripID>\d+)/delete/process$', views.deleteProcess),
    # url(r'^trip/create$', views.create),
    # url(r'^trip/create/process$', views.createProcess),
    url(r'^logout$', views.logout),
    url(r'^login/process$', views.login),
    url(r'^email$', views.email)
]