from django.apps import AppConfig


class TimeAppsConfig(AppConfig):
    name = 'time_apps'
